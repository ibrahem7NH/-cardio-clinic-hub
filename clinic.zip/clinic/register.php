<?php
$page_title = 'إنشاء حساب';
require_once __DIR__ . '/includes/auth.php';

if (is_logged_in()) { header('Location: dashboard.php'); exit; }

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();

    $role = $_POST['role'] ?? 'patient';
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm'] ?? '';
    $full_name = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $specialty_id = $_POST['specialty_id'] ?? null;
    $license = trim($_POST['license_number'] ?? '');

    if (!in_array($role, ['patient','doctor'])) $errors[] = 'دور غير صالح';
    if (strlen($username) < 3) $errors[] = 'اسم المستخدم قصير جداً';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'البريد الإلكتروني غير صالح';
    if (strlen($password) < 8) $errors[] = 'كلمة المرور يجب ٨ أحرف على الأقل';
    if ($password !== $confirm) $errors[] = 'كلمتا المرور غير متطابقتين';
    if (strlen($full_name) < 3) $errors[] = 'الاسم الكامل مطلوب';
    if ($role === 'doctor' && (empty($specialty_id) || empty($license))) {
        $errors[] = 'التخصص ورقم الترخيص مطلوبان للأطباء';
    }

    if (!$errors) {
        $stmt = $pdo->prepare('SELECT id FROM users WHERE username = ? OR email = ?');
        $stmt->execute([$username, $email]);
        if ($stmt->fetch()) {
            $errors[] = 'اسم المستخدم أو البريد مستخدم مسبقاً';
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $status = $role === 'doctor' ? 'pending' : 'active';
            $stmt = $pdo->prepare('INSERT INTO users (username,email,password,full_name,phone,role,status,specialty_id,license_number) VALUES (?,?,?,?,?,?,?,?,?)');
            $stmt->execute([
                $username, $email, $hash, $full_name, $phone, $role, $status,
                $role === 'doctor' ? $specialty_id : null,
                $role === 'doctor' ? $license : null
            ]);
            $new_id = $pdo->lastInsertId();

            if ($role === 'patient') {
                $pdo->prepare('INSERT INTO medical_records (patient_id) VALUES (?)')->execute([$new_id]);
            }

            log_action('register', "حساب جديد ($role): $username", 'user', $new_id);

            if ($role === 'doctor') {
                flash('success', 'تم إنشاء حسابك! بانتظار موافقة الأدمن.');
            } else {
                flash('success', 'تم إنشاء الحساب بنجاح، يمكنك تسجيل الدخول.');
            }
            header('Location: login.php'); exit;
        }
    }
}

$specialties = $pdo->query('SELECT * FROM specialties ORDER BY name')->fetchAll();
require_once __DIR__ . '/includes/header.php';
?>
<div class="auth-page">
  <div class="card auth-card">
    <h1>إنشاء حساب جديد</h1>
    <?php foreach ($errors as $e): ?>
      <div class="alert alert-error"><?= e($e) ?></div>
    <?php endforeach; ?>
    <form method="post">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
      <div class="form-group">
        <label>نوع الحساب</label>
        <select name="role" id="roleSelect" required>
          <option value="patient">مريض</option>
          <option value="doctor">طبيب</option>
        </select>
      </div>
      <div class="form-row">
        <div class="form-group"><label>اسم المستخدم</label><input type="text" name="username" required></div>
        <div class="form-group"><label>الاسم الكامل</label><input type="text" name="full_name" required></div>
      </div>
      <div class="form-group"><label>البريد الإلكتروني</label><input type="email" name="email" required></div>
      <div class="form-group"><label>رقم الهاتف</label><input type="tel" name="phone"></div>
      <div class="form-row">
        <div class="form-group"><label>كلمة المرور</label><input type="password" name="password" required minlength="8"></div>
        <div class="form-group"><label>تأكيد كلمة المرور</label><input type="password" name="confirm" required></div>
      </div>
      <div id="doctorFields" style="display:none">
        <div class="form-row">
          <div class="form-group">
            <label>التخصص</label>
            <select name="specialty_id">
              <option value="">— اختر —</option>
              <?php foreach ($specialties as $s): ?>
                <option value="<?= $s['id'] ?>"><?= e($s['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group"><label>رقم الترخيص</label><input type="text" name="license_number"></div>
        </div>
      </div>
      <button type="submit" class="btn-primary" style="width:100%">إنشاء الحساب</button>
    </form>
    <p style="text-align:center;margin-top:14px;font-size:14px">
      لديك حساب؟ <a href="login.php" style="color:var(--primary)">سجّل الدخول</a>
    </p>
  </div>
</div>
<script>
document.getElementById('roleSelect').addEventListener('change', e => {
  document.getElementById('doctorFields').style.display = e.target.value === 'doctor' ? 'block' : 'none';
});
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
