<?php
$page_title = 'الملف الشخصي';
require_once __DIR__ . '/includes/auth.php';
require_login();
$u = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    if (isset($_POST['update_info'])) {
        $full_name = trim($_POST['full_name']);
        $phone = trim($_POST['phone']);
        $address = trim($_POST['address']);
        $pdo->prepare('UPDATE users SET full_name=?, phone=?, address=? WHERE id=?')->execute([$full_name,$phone,$address,$u['id']]);
        log_action('update_profile', 'تعديل الملف الشخصي');
        flash('success','تم تحديث البيانات');
        header('Location: profile.php'); exit;
    }
    if (isset($_POST['change_password'])) {
        $old = $_POST['old_password']; $new = $_POST['new_password'];
        if (!password_verify($old, $u['password'])) {
            flash('error','كلمة المرور القديمة غير صحيحة');
        } elseif (strlen($new) < 8) {
            flash('error','كلمة المرور الجديدة قصيرة');
        } else {
            $pdo->prepare('UPDATE users SET password=? WHERE id=?')->execute([password_hash($new,PASSWORD_BCRYPT),$u['id']]);
            log_action('change_password','تغيير كلمة المرور');
            flash('success','تم تغيير كلمة المرور');
        }
        header('Location: profile.php'); exit;
    }
}
require_once __DIR__ . '/includes/header.php';
?>
<div class="card">
  <h2>بياناتي</h2>
  <form method="post">
    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
    <div class="form-row">
      <div class="form-group"><label>اسم المستخدم</label><input type="text" value="<?= e($u['username']) ?>" disabled></div>
      <div class="form-group"><label>البريد</label><input type="email" value="<?= e($u['email']) ?>" disabled></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>الاسم الكامل</label><input type="text" name="full_name" value="<?= e($u['full_name']) ?>" required></div>
      <div class="form-group"><label>الهاتف</label><input type="tel" name="phone" value="<?= e($u['phone']) ?>"></div>
    </div>
    <div class="form-group"><label>العنوان</label><textarea name="address" rows="2"><?= e($u['address']) ?></textarea></div>
    <button type="submit" name="update_info" class="btn-primary">حفظ</button>
  </form>
</div>

<div class="card">
  <h2>تغيير كلمة المرور</h2>
  <form method="post">
    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
    <div class="form-group"><label>كلمة المرور الحالية</label><input type="password" name="old_password" required></div>
    <div class="form-group"><label>كلمة المرور الجديدة</label><input type="password" name="new_password" required minlength="8"></div>
    <button type="submit" name="change_password" class="btn-primary">تغيير</button>
  </form>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
