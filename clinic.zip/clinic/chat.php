<?php
// شاشة المحادثة المباشرة بين مريض وطبيب
require_once __DIR__ . '/includes/messages.php';
require_login();
$user = current_user();
$page_title = 'محادثة';

// تحديد المحادثة
$conv = null;
if (isset($_GET['conversation_id'])) {
    $stmt = $pdo->prepare('SELECT * FROM conversations WHERE id=?');
    $stmt->execute([(int)$_GET['conversation_id']]);
    $conv = $stmt->fetch();
} elseif ($user['role']==='patient' && isset($_GET['doctor_id'])) {
    // التحقق من أن الطبيب موجود ومُعتمد
    $d = $pdo->prepare("SELECT id FROM users WHERE id=? AND role='doctor' AND status IN('approved','active')");
    $d->execute([(int)$_GET['doctor_id']]);
    if ($d->fetch()) {
        $conv = get_or_create_conversation($user['id'], (int)$_GET['doctor_id']);
    }
} elseif ($user['role']==='doctor' && isset($_GET['patient_id'])) {
    $p = $pdo->prepare("SELECT id FROM users WHERE id=? AND role='patient'");
    $p->execute([(int)$_GET['patient_id']]);
    if ($p->fetch()) {
        $conv = get_or_create_conversation((int)$_GET['patient_id'], $user['id']);
    }
}

if (!$conv || !user_in_conversation($conv, $user)) {
    flash('error', 'المحادثة غير موجودة أو لا تملك صلاحية الوصول');
    header('Location: /clinic/messages.php'); exit;
}

// معلومات الطرف الآخر
$other_id = $user['role']==='patient' ? $conv['doctor_id'] : $conv['patient_id'];
$o = $pdo->prepare('SELECT id, full_name, role FROM users WHERE id=?');
$o->execute([$other_id]);
$other = $o->fetch();

// إرسال رسالة
if ($_SERVER['REQUEST_METHOD']==='POST') {
    require_csrf();
    if ($user['role']==='admin') {
        flash('error','الأدمن للقراءة فقط');
        header('Location: /clinic/chat.php?conversation_id='.$conv['id']); exit;
    }
    $body = trim($_POST['body'] ?? '');
    $image_path = null;

    if (!empty($_FILES['image']['name']) && $_FILES['image']['error']===UPLOAD_ERR_OK) {
        $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($_FILES['image']['tmp_name']);
        if (!isset($allowed[$mime])) {
            flash('error','نوع الصورة غير مدعوم (jpg, png, webp, gif فقط)');
            header('Location: /clinic/chat.php?conversation_id='.$conv['id']); exit;
        }
        if ($_FILES['image']['size'] > 5*1024*1024) {
            flash('error','حجم الصورة أكبر من 5 ميجابايت');
            header('Location: /clinic/chat.php?conversation_id='.$conv['id']); exit;
        }
        $dir = __DIR__ . '/uploads/chat';
        if (!is_dir($dir)) mkdir($dir, 0775, true);
        $name = 'msg_'.$conv['id'].'_'.time().'_'.bin2hex(random_bytes(4)).'.'.$allowed[$mime];
        if (move_uploaded_file($_FILES['image']['tmp_name'], $dir.'/'.$name)) {
            $image_path = 'uploads/chat/'.$name;
        }
    }

    if ($body==='' && !$image_path) {
        flash('error','لا يمكن إرسال رسالة فارغة');
    } else {
        $pdo->prepare('INSERT INTO messages (conversation_id, sender_id, body, image_path) VALUES (?,?,?,?)')
            ->execute([$conv['id'], $user['id'], $body ?: null, $image_path]);
        $pdo->prepare('UPDATE conversations SET last_message_at=NOW() WHERE id=?')->execute([$conv['id']]);
        log_action('send_message','رسالة في المحادثة #'.$conv['id'],'message',$pdo->lastInsertId());
    }
    header('Location: /clinic/chat.php?conversation_id='.$conv['id']); exit;
}

// تعليم رسائل الطرف الآخر كمقروءة
$pdo->prepare('UPDATE messages SET is_read=1 WHERE conversation_id=? AND sender_id<>? AND is_read=0')
    ->execute([$conv['id'], $user['id']]);

// جلب الرسائل
$stmt = $pdo->prepare('SELECT m.*, u.full_name FROM messages m JOIN users u ON u.id=m.sender_id
    WHERE m.conversation_id=? ORDER BY m.id ASC');
$stmt->execute([$conv['id']]);
$messages = $stmt->fetchAll();

include __DIR__ . '/includes/header.php';
?>
<div class="page-header" style="display:flex;justify-content:space-between;align-items:center">
  <h1>💬 محادثة مع <?= e($other['full_name']) ?> <small style="color:#888;font-size:.8rem">(<?= $other['role']==='doctor'?'طبيب':'مريض' ?>)</small></h1>
  <a href="/clinic/messages.php" class="btn-secondary">← كل المحادثات</a>
</div>

<div class="card chat-box" id="chatBox" style="max-height:60vh;overflow-y:auto;display:flex;flex-direction:column;gap:.6rem;padding:1rem">
  <?php if (!$messages): ?>
    <p style="text-align:center;color:#888;padding:2rem">ابدأ المحادثة الآن…</p>
  <?php endif; ?>
  <?php foreach($messages as $m): $mine = $m['sender_id']==$user['id']; ?>
    <div style="display:flex;justify-content:<?= $mine?'flex-start':'flex-end' ?>">
      <div style="max-width:70%;background:<?= $mine?'#0a7':'#0d6efd' ?>;color:#fff;padding:.6rem .85rem;border-radius:14px;border-<?= $mine?'top-right':'top-left' ?>-radius:4px">
        <div style="font-size:.75rem;opacity:.85;margin-bottom:.25rem"><?= e($m['full_name']) ?></div>
        <?php if (!empty($m['image_path'])): ?>
          <a href="/clinic/<?= e($m['image_path']) ?>" target="_blank">
            <img src="/clinic/<?= e($m['image_path']) ?>" alt="مرفق" style="max-width:260px;max-height:260px;border-radius:8px;display:block;margin-bottom:.4rem">
          </a>
        <?php endif; ?>
        <?php if (!empty($m['body'])): ?>
          <div style="white-space:pre-wrap;word-break:break-word"><?= e($m['body']) ?></div>
        <?php endif; ?>
        <div style="font-size:.7rem;opacity:.7;margin-top:.3rem;text-align:left"><?= e($m['created_at']) ?></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<?php if ($user['role']!=='admin'): ?>
<form method="post" enctype="multipart/form-data" class="card" style="margin-top:1rem;display:flex;flex-direction:column;gap:.6rem">
  <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
  <textarea name="body" rows="2" placeholder="اكتب رسالتك…" class="form-control"></textarea>
  <div style="display:flex;gap:.6rem;align-items:center;flex-wrap:wrap">
    <label class="btn-secondary" style="cursor:pointer;margin:0">
      📎 إرفاق صورة
      <input type="file" name="image" accept="image/*" style="display:none" onchange="document.getElementById('fname').textContent=this.files[0]?.name||''">
    </label>
    <span id="fname" style="color:#666;font-size:.9rem"></span>
    <div style="flex:1"></div>
    <button class="btn-primary">إرسال ✉</button>
  </div>
  <small style="color:#888">الحد الأقصى للصورة 5MB — الأنواع المدعومة: jpg, png, webp, gif</small>
</form>
<?php else: ?>
<div class="alert alert-info">عرض للقراءة فقط (الأدمن)</div>
<?php endif; ?>

<script>
  const box = document.getElementById('chatBox');
  if (box) box.scrollTop = box.scrollHeight;
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
