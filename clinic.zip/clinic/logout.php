<?php
require_once __DIR__ . '/includes/auth.php';
if (is_logged_in()) {
    log_action('logout', 'تسجيل خروج');
}
session_unset();
session_destroy();
header('Location: login.php');
exit;
