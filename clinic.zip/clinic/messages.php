<?php
// قائمة المحادثات (مشتركة بين المريض والطبيب)
require_once __DIR__ . '/includes/messages.php';
require_login();
$user = current_user();
$page_title = 'المحادثات';

if (!in_array($user['role'], ['patient','doctor','admin'])) {
    header('Location: /clinic/dashboard.php'); exit;
}

// قائمة المحادثات الحالية
if ($user['role']==='patient') {
    $stmt = $pdo->prepare("SELECT c.*, u.full_name AS other_name, u.id AS other_id,
        (SELECT body FROM messages WHERE conversation_id=c.id ORDER BY id DESC LIMIT 1) AS last_body,
        (SELECT COUNT(*) FROM messages WHERE conversation_id=c.id AND sender_id<>? AND is_read=0) AS unread
        FROM conversations c JOIN users u ON u.id=c.doctor_id
        WHERE c.patient_id=? ORDER BY c.last_message_at DESC");
    $stmt->execute([$user['id'], $user['id']]);
} elseif ($user['role']==='doctor') {
    $stmt = $pdo->prepare("SELECT c.*, u.full_name AS other_name, u.id AS other_id,
        (SELECT body FROM messages WHERE conversation_id=c.id ORDER BY id DESC LIMIT 1) AS last_body,
        (SELECT COUNT(*) FROM messages WHERE conversation_id=c.id AND sender_id<>? AND is_read=0) AS unread
        FROM conversations c JOIN users u ON u.id=c.patient_id
        WHERE c.doctor_id=? ORDER BY c.last_message_at DESC");
    $stmt->execute([$user['id'], $user['id']]);
} else {
    $stmt = $pdo->query("SELECT c.*, p.full_name AS patient_name, d.full_name AS doctor_name
        FROM conversations c JOIN users p ON p.id=c.patient_id JOIN users d ON d.id=c.doctor_id
        ORDER BY c.last_message_at DESC");
}
$conversations = $stmt->fetchAll();

// للمريض: قائمة الأطباء المتاحين لبدء محادثة جديدة
$doctors = [];
if ($user['role']==='patient') {
    $doctors = $pdo->query("SELECT id, full_name FROM users WHERE role='doctor' AND status IN('approved','active') ORDER BY full_name")->fetchAll();
}

include __DIR__ . '/includes/header.php';
?>
<div class="page-header">
  <h1>💬 المحادثات</h1>
</div>

<?php if ($user['role']==='patient' && $doctors): ?>
<div class="card" style="margin-bottom:1rem">
  <form method="get" action="/clinic/chat.php" style="display:flex;gap:.5rem;align-items:center;flex-wrap:wrap">
    <label><strong>بدء محادثة مع طبيب:</strong></label>
    <select name="doctor_id" required class="form-control" style="min-width:220px">
      <option value="">— اختر طبيباً —</option>
      <?php foreach($doctors as $d): ?>
        <option value="<?= (int)$d['id'] ?>"><?= e($d['full_name']) ?></option>
      <?php endforeach; ?>
    </select>
    <button class="btn-primary">فتح المحادثة</button>
  </form>
</div>
<?php endif; ?>

<div class="card">
<?php if (!$conversations): ?>
  <p style="text-align:center;padding:2rem;color:#777">لا توجد محادثات بعد.</p>
<?php else: ?>
  <ul class="conv-list" style="list-style:none;padding:0;margin:0">
    <?php foreach($conversations as $c): ?>
      <?php
        if ($user['role']==='admin') {
          $title = 'مريض: '.$c['patient_name'].' ↔ طبيب: '.$c['doctor_name'];
          $href = '/clinic/chat.php?conversation_id='.$c['id'];
          $unread = 0;
        } else {
          $title = $c['other_name'];
          $href = '/clinic/chat.php?conversation_id='.$c['id'];
          $unread = (int)$c['unread'];
        }
      ?>
      <li style="border-bottom:1px solid var(--border,#eee);padding:.85rem 0">
        <a href="<?= $href ?>" style="display:flex;justify-content:space-between;align-items:center;text-decoration:none;color:inherit">
          <div>
            <div style="font-weight:700"><?= e($title) ?></div>
            <?php if (!empty($c['last_body'])): ?>
              <div style="color:#777;font-size:.9rem;margin-top:.25rem"><?= e(mb_substr($c['last_body'],0,80)) ?></div>
            <?php endif; ?>
          </div>
          <div style="display:flex;gap:.5rem;align-items:center">
            <span style="font-size:.8rem;color:#999"><?= e($c['last_message_at']) ?></span>
            <?php if (!empty($unread)): ?>
              <span style="background:#e11;color:#fff;border-radius:999px;padding:.15rem .55rem;font-size:.8rem"><?= $unread ?></span>
            <?php endif; ?>
          </div>
        </a>
      </li>
    <?php endforeach; ?>
  </ul>
<?php endif; ?>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
