<?php
$page_title = 'لوحة الأدمن';
require_once __DIR__ . '/../includes/auth.php';
require_role('admin');

$users_count = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$patients_count = $pdo->query("SELECT COUNT(*) FROM users WHERE role='patient'")->fetchColumn();
$doctors_count = $pdo->query("SELECT COUNT(*) FROM users WHERE role='doctor' AND status='approved'")->fetchColumn();
$pending_doctors = $pdo->query("SELECT COUNT(*) FROM users WHERE role='doctor' AND status='pending'")->fetchColumn();
$appts_total = $pdo->query("SELECT COUNT(*) FROM appointments")->fetchColumn();
$appts_today = $pdo->query("SELECT COUNT(*) FROM appointments WHERE appointment_date=CURDATE()")->fetchColumn();
$rx_count = $pdo->query("SELECT COUNT(*) FROM prescriptions")->fetchColumn();

// مواعيد آخر 7 أيام
$chart = $pdo->query("SELECT DATE(appointment_date) AS d, COUNT(*) AS c FROM appointments WHERE appointment_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) GROUP BY d ORDER BY d")->fetchAll();
$max_chart = max(array_column($chart,'c') ?: [1]);

require_once __DIR__ . '/../includes/header.php';
?>
<div class="card">
  <h2>لوحة الإحصائيات</h2>
  <div class="stats-grid">
    <div class="stat-card"><div class="stat-value"><?= $users_count ?></div><div class="stat-label">إجمالي المستخدمين</div></div>
    <div class="stat-card"><div class="stat-value"><?= $patients_count ?></div><div class="stat-label">المرضى</div></div>
    <div class="stat-card"><div class="stat-value"><?= $doctors_count ?></div><div class="stat-label">الأطباء المعتمدون</div></div>
    <div class="stat-card" style="border-color:var(--warning)"><div class="stat-value" style="color:var(--warning)"><?= $pending_doctors ?></div><div class="stat-label">أطباء بانتظار الموافقة</div></div>
    <div class="stat-card"><div class="stat-value"><?= $appts_total ?></div><div class="stat-label">إجمالي المواعيد</div></div>
    <div class="stat-card"><div class="stat-value"><?= $appts_today ?></div><div class="stat-label">مواعيد اليوم</div></div>
    <div class="stat-card"><div class="stat-value"><?= $rx_count ?></div><div class="stat-label">الوصفات الطبية</div></div>
  </div>
</div>

<div class="card">
  <h3>المواعيد خلال آخر 7 أيام</h3>
  <div style="display:flex;align-items:flex-end;gap:8px;height:160px;padding:10px 0">
    <?php foreach($chart as $row):
      $h = ($row['c'] / $max_chart) * 140; ?>
    <div style="flex:1;text-align:center">
      <div style="background:var(--primary);height:<?= $h ?>px;border-radius:6px 6px 0 0;min-height:4px"></div>
      <div style="font-size:12px;margin-top:4px;color:var(--text-muted)"><?= e($row['d']) ?></div>
      <div style="font-size:13px;font-weight:700"><?= $row['c'] ?></div>
    </div>
    <?php endforeach; ?>
    <?php if(!$chart): ?><p style="color:var(--text-muted)">لا توجد بيانات</p><?php endif; ?>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
