<?php
$page_title = 'موافقات الأطباء';
require_once __DIR__ . '/../includes/auth.php';
require_role('admin');

if ($_SERVER['REQUEST_METHOD']==='POST') {
    require_csrf();
    $id = (int)$_POST['id'];
    if (isset($_POST['approve'])) {
        $pdo->prepare("UPDATE users SET status='approved' WHERE id=? AND role='doctor'")->execute([$id]);
        log_action('approve_doctor','الموافقة على طبيب','user',$id);
        flash('success','تمت الموافقة');
    } elseif (isset($_POST['reject'])) {
        $pdo->prepare("UPDATE users SET status='rejected' WHERE id=? AND role='doctor'")->execute([$id]);
        log_action('reject_doctor','رفض طبيب','user',$id);
        flash('success','تم الرفض');
    }
    header('Location: approve-doctors.php'); exit;
}

$pending = $pdo->query("SELECT u.*, s.name AS specialty_name FROM users u LEFT JOIN specialties s ON u.specialty_id=s.id WHERE u.role='doctor' AND u.status='pending' ORDER BY u.created_at DESC")->fetchAll();
require_once __DIR__ . '/../includes/header.php';
?>
<div class="card">
  <h2>طلبات تسجيل الأطباء</h2>
  <?php if (!$pending): ?><p style="color:var(--text-muted)">لا توجد طلبات معلقة</p>
  <?php else: ?>
  <div class="table-wrap"><table>
    <tr><th>الاسم</th><th>اسم المستخدم</th><th>البريد</th><th>التخصص</th><th>الترخيص</th><th>الهاتف</th><th>إجراءات</th></tr>
    <?php foreach($pending as $d): ?>
    <tr>
      <td><?= e($d['full_name']) ?></td>
      <td><?= e($d['username']) ?></td>
      <td><?= e($d['email']) ?></td>
      <td><?= e($d['specialty_name']) ?></td>
      <td><?= e($d['license_number']) ?></td>
      <td><?= e($d['phone']) ?></td>
      <td class="row-actions">
        <form method="post" style="display:inline">
          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
          <input type="hidden" name="id" value="<?= $d['id'] ?>">
          <button name="approve" class="btn-success">موافقة</button>
        </form>
        <form method="post" data-confirm="رفض هذا الطبيب؟" style="display:inline">
          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
          <input type="hidden" name="id" value="<?= $d['id'] ?>">
          <button name="reject" class="btn-danger">رفض</button>
        </form>
      </td>
    </tr>
    <?php endforeach; ?>
  </table></div>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
