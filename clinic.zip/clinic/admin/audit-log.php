<?php
$page_title = 'سجل العمليات';
require_once __DIR__ . '/../includes/auth.php';
require_role('admin');

$page = max(1,(int)($_GET['page'] ?? 1)); $per = 30; $offset = ($page-1)*$per;
$total = $pdo->query('SELECT COUNT(*) FROM audit_log')->fetchColumn();
$pages = ceil($total/$per);

$rows = $pdo->query("SELECT l.*, u.username FROM audit_log l LEFT JOIN users u ON l.user_id=u.id ORDER BY l.created_at DESC LIMIT $per OFFSET $offset")->fetchAll();
require_once __DIR__ . '/../includes/header.php';
?>
<div class="card">
  <h2>سجل العمليات</h2>
  <div class="table-wrap"><table>
    <tr><th>الوقت</th><th>المستخدم</th><th>العملية</th><th>الوصف</th><th>IP</th></tr>
    <?php foreach($rows as $r): ?>
    <tr>
      <td><?= e($r['created_at']) ?></td>
      <td><?= e($r['username'] ?? '—') ?></td>
      <td><?= e($r['action']) ?></td>
      <td><?= e($r['description']) ?></td>
      <td><?= e($r['ip_address']) ?></td>
    </tr>
    <?php endforeach; ?>
  </table></div>
  <?php if ($pages>1): ?>
  <div class="pagination">
    <?php for($i=max(1,$page-3);$i<=min($pages,$page+3);$i++): ?>
      <a href="?page=<?= $i ?>" class="<?= $i==$page?'active':'' ?>"><?= $i ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
