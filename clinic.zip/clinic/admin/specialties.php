<?php
$page_title = 'التخصصات';
require_once __DIR__ . '/../includes/auth.php';
require_role('admin');

if ($_SERVER['REQUEST_METHOD']==='POST') {
    require_csrf();
    if (isset($_POST['add'])) {
        try {
            $pdo->prepare('INSERT INTO specialties (name,description) VALUES (?,?)')->execute([trim($_POST['name']),trim($_POST['description'])]);
            log_action('add_specialty','إضافة تخصص');
            flash('success','تمت الإضافة');
        } catch(PDOException $e) { flash('error','الاسم موجود مسبقاً'); }
    }
    if (isset($_POST['delete'])) {
        $pdo->prepare('DELETE FROM specialties WHERE id=?')->execute([(int)$_POST['id']]);
        log_action('delete_specialty','حذف تخصص');
        flash('success','تم الحذف');
    }
    header('Location: specialties.php'); exit;
}
$rows = $pdo->query('SELECT * FROM specialties ORDER BY name')->fetchAll();
require_once __DIR__ . '/../includes/header.php';
?>
<div class="card">
  <h2>إضافة تخصص</h2>
  <form method="post">
    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
    <div class="form-row">
      <div class="form-group"><label>الاسم</label><input type="text" name="name" required></div>
      <div class="form-group"><label>الوصف</label><input type="text" name="description"></div>
    </div>
    <button name="add" class="btn-primary">إضافة</button>
  </form>
</div>
<div class="card">
  <h2>التخصصات</h2>
  <div class="table-wrap"><table>
    <tr><th>الاسم</th><th>الوصف</th><th></th></tr>
    <?php foreach($rows as $r): ?>
    <tr>
      <td><?= e($r['name']) ?></td>
      <td><?= e($r['description']) ?></td>
      <td>
        <form method="post" data-confirm="حذف التخصص؟" style="display:inline">
          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
          <input type="hidden" name="id" value="<?= $r['id'] ?>">
          <button name="delete" class="btn-danger">حذف</button>
        </form>
      </td>
    </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
