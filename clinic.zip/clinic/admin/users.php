<?php
$page_title = 'إدارة المستخدمين';
require_once __DIR__ . '/../includes/auth.php';
require_role('admin');

if ($_SERVER['REQUEST_METHOD']==='POST') {
    require_csrf();
    $id = (int)$_POST['id'];
    if ($id == $_SESSION['user_id']) { flash('error','لا يمكن تعديل حسابك من هنا'); header('Location: users.php'); exit; }
    if (isset($_POST['delete'])) {
        $pdo->prepare('DELETE FROM users WHERE id=?')->execute([$id]);
        log_action('delete_user','حذف مستخدم','user',$id);
        flash('success','تم الحذف');
    }
    if (isset($_POST['toggle_status'])) {
        $stmt = $pdo->prepare('SELECT status FROM users WHERE id=?');
        $stmt->execute([$id]); $s = $stmt->fetchColumn();
        $new = ($s==='active'||$s==='approved') ? 'rejected' : 'active';
        $pdo->prepare('UPDATE users SET status=? WHERE id=?')->execute([$new,$id]);
        log_action('toggle_status',"تغيير حالة إلى $new",'user',$id);
        flash('success','تم التحديث');
    }
    header('Location: users.php?'.http_build_query(['role'=>$_GET['role']??'','q'=>$_GET['q']??''])); exit;
}

$role_filter = $_GET['role'] ?? ''; $search = trim($_GET['q'] ?? '');
$page = max(1,(int)($_GET['page'] ?? 1)); $per = 20; $offset = ($page-1)*$per;

$where = []; $params = [];
if ($role_filter) { $where[] = 'role=?'; $params[] = $role_filter; }
if ($search) { $where[] = '(full_name LIKE ? OR username LIKE ? OR email LIKE ?)'; $params[]="%$search%"; $params[]="%$search%"; $params[]="%$search%"; }
$wsql = $where ? 'WHERE '.implode(' AND ',$where) : '';

$total = $pdo->prepare("SELECT COUNT(*) FROM users $wsql");
$total->execute($params); $total = $total->fetchColumn();
$pages = ceil($total/$per);

$stmt = $pdo->prepare("SELECT * FROM users $wsql ORDER BY created_at DESC LIMIT $per OFFSET $offset");
$stmt->execute($params); $rows = $stmt->fetchAll();
require_once __DIR__ . '/../includes/header.php';
?>
<div class="card">
  <h2>المستخدمون</h2>
  <form class="toolbar" method="get">
    <input type="text" name="q" placeholder="بحث" value="<?= e($search) ?>">
    <select name="role">
      <option value="">كل الأدوار</option>
      <option value="patient" <?= $role_filter==='patient'?'selected':'' ?>>مريض</option>
      <option value="doctor" <?= $role_filter==='doctor'?'selected':'' ?>>طبيب</option>
      <option value="admin" <?= $role_filter==='admin'?'selected':'' ?>>أدمن</option>
    </select>
    <button class="btn-primary">تصفية</button>
  </form>
  <div class="table-wrap"><table>
    <tr><th>الاسم</th><th>المستخدم</th><th>البريد</th><th>الدور</th><th>الحالة</th><th>إجراءات</th></tr>
    <?php foreach($rows as $r): ?>
    <tr>
      <td><?= e($r['full_name']) ?></td>
      <td><?= e($r['username']) ?></td>
      <td><?= e($r['email']) ?></td>
      <td><?= e($r['role']) ?></td>
      <td><span class="badge badge-<?= e($r['status']) ?>"><?= e($r['status']) ?></span></td>
      <td class="row-actions">
        <?php if ($r['id'] != $_SESSION['user_id']): ?>
        <form method="post" style="display:inline">
          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
          <input type="hidden" name="id" value="<?= $r['id'] ?>">
          <button name="toggle_status" class="btn-secondary">تفعيل/تعطيل</button>
        </form>
        <form method="post" data-confirm="حذف المستخدم نهائياً؟" style="display:inline">
          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
          <input type="hidden" name="id" value="<?= $r['id'] ?>">
          <button name="delete" class="btn-danger">حذف</button>
        </form>
        <?php else: ?>
        <span style="color:var(--text-muted);font-size:12px">(أنت)</span>
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
  </table></div>
  <?php if ($pages>1): ?>
  <div class="pagination">
    <?php for($i=1;$i<=$pages;$i++): ?>
      <a href="?page=<?= $i ?>&q=<?= urlencode($search) ?>&role=<?= urlencode($role_filter) ?>" class="<?= $i==$page?'active':'' ?>"><?= $i ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
