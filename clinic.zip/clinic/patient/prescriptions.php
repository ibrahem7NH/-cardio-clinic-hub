<?php
$page_title = 'وصفاتي';
require_once __DIR__ . '/../includes/auth.php';
require_role('patient');
$u = current_user();

$stmt = $pdo->prepare('SELECT p.*, d.full_name AS doctor_name FROM prescriptions p JOIN users d ON p.doctor_id=d.id WHERE p.patient_id=? ORDER BY p.issued_at DESC');
$stmt->execute([$u['id']]);
$rxs = $stmt->fetchAll();
require_once __DIR__ . '/../includes/header.php';
?>
<div class="card">
  <h2>وصفاتي الطبية</h2>
  <?php if (!$rxs): ?><p style="color:var(--text-muted)">لا توجد وصفات</p>
  <?php else: foreach($rxs as $rx):
    $meds = $pdo->prepare('SELECT * FROM prescription_medications WHERE prescription_id=?');
    $meds->execute([$rx['id']]); $meds = $meds->fetchAll();
  ?>
  <div style="border:1px solid var(--border);border-radius:8px;padding:16px;margin-bottom:14px">
    <div style="display:flex;justify-content:space-between;margin-bottom:10px">
      <strong><?= e($rx['issued_at']) ?> — <?= e($rx['doctor_name']) ?></strong>
      <button onclick="window.print()" class="btn-secondary">طباعة</button>
    </div>
    <p><strong>التشخيص:</strong> <?= e($rx['diagnosis']) ?></p>
    <?php if ($meds): ?>
    <table style="margin-top:10px">
      <tr><th>الدواء</th><th>الجرعة</th><th>التكرار</th><th>المدة</th><th>تعليمات</th></tr>
      <?php foreach($meds as $m): ?>
      <tr>
        <td><?= e($m['medication_name']) ?></td>
        <td><?= e($m['dosage']) ?></td>
        <td><?= e($m['frequency']) ?></td>
        <td><?= e($m['duration']) ?></td>
        <td><?= e($m['instructions']) ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
    <?php endif; ?>
    <?php if ($rx['notes']): ?><p style="margin-top:10px"><strong>ملاحظات:</strong> <?= e($rx['notes']) ?></p><?php endif; ?>
  </div>
  <?php endforeach; endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
