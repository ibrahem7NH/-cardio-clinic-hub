<?php
$page_title = 'متابعة الأدوية';
require_once __DIR__ . '/../includes/auth.php';
require_role('patient');
$u = current_user();

// كل أدوية الوصفات الأخيرة (آخر 30 يوم)
$stmt = $pdo->prepare('SELECT pm.*, p.issued_at, d.full_name AS doctor_name 
  FROM prescription_medications pm 
  JOIN prescriptions p ON pm.prescription_id=p.id 
  JOIN users d ON p.doctor_id=d.id 
  WHERE p.patient_id=? AND p.issued_at >= DATE_SUB(CURDATE(), INTERVAL 60 DAY)
  ORDER BY p.issued_at DESC');
$stmt->execute([$u['id']]);
$meds = $stmt->fetchAll();
require_once __DIR__ . '/../includes/header.php';
?>
<div class="card">
  <h2>متابعة الأدوية الحالية</h2>
  <p style="color:var(--text-muted)">أدوية موصوفة خلال آخر 60 يوماً</p>
  <?php if (!$meds): ?><p>لا توجد أدوية حالية</p>
  <?php else: ?>
  <div class="table-wrap"><table>
    <tr><th>الدواء</th><th>الجرعة</th><th>التكرار</th><th>المدة</th><th>الطبيب</th><th>تاريخ الوصف</th></tr>
    <?php foreach($meds as $m): ?>
    <tr>
      <td><strong><?= e($m['medication_name']) ?></strong></td>
      <td><?= e($m['dosage']) ?></td>
      <td><?= e($m['frequency']) ?></td>
      <td><?= e($m['duration']) ?></td>
      <td><?= e($m['doctor_name']) ?></td>
      <td><?= e($m['issued_at']) ?></td>
    </tr>
    <?php endforeach; ?>
  </table></div>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
