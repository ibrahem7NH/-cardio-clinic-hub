<?php
$page_title = 'ملفي الطبي';
require_once __DIR__ . '/../includes/auth.php';
require_role('patient');
$u = current_user();

$stmt = $pdo->prepare('SELECT * FROM medical_records WHERE patient_id=?');
$stmt->execute([$u['id']]);
$record = $stmt->fetch();
if (!$record) {
    $pdo->prepare('INSERT INTO medical_records (patient_id) VALUES (?)')->execute([$u['id']]);
    $stmt->execute([$u['id']]); $record = $stmt->fetch();
}
require_once __DIR__ . '/../includes/header.php';
?>
<div class="card">
  <h2>ملفي الطبي</h2>
  <p style="color:var(--text-muted);margin-bottom:16px">يقوم الطبيب بتحديث هذه البيانات. للتعديل، تواصل مع طبيبك.</p>
  <div class="form-row">
    <div class="form-group"><label>فصيلة الدم</label><input type="text" value="<?= e($record['blood_type']) ?>" disabled></div>
    <div class="form-group"><label>ضغط الدم</label><input type="text" value="<?= e($record['blood_pressure']) ?>" disabled></div>
  </div>
  <div class="form-row">
    <div class="form-group"><label>السكر</label><input type="text" value="<?= e($record['sugar_level']) ?>" disabled></div>
    <div class="form-group"><label>الكوليسترول</label><input type="text" value="<?= e($record['cholesterol']) ?>" disabled></div>
  </div>
  <div class="form-row">
    <div class="form-group"><label>الوزن (كغ)</label><input type="text" value="<?= e($record['weight']) ?>" disabled></div>
    <div class="form-group"><label>الطول (سم)</label><input type="text" value="<?= e($record['height']) ?>" disabled></div>
  </div>
  <div class="form-group"><label>الحساسية</label><textarea disabled rows="2"><?= e($record['allergies']) ?></textarea></div>
  <div class="form-group"><label>الأمراض المزمنة</label><textarea disabled rows="2"><?= e($record['chronic_diseases']) ?></textarea></div>
  <div class="form-group"><label>الأدوية الحالية</label><textarea disabled rows="2"><?= e($record['current_medications']) ?></textarea></div>
  <div class="form-group"><label>التاريخ العائلي</label><textarea disabled rows="2"><?= e($record['family_history']) ?></textarea></div>
  <div class="form-group"><label>ملاحظات الطبيب</label><textarea disabled rows="3"><?= e($record['notes']) ?></textarea></div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
