<?php
$page_title = 'مواعيدي';
require_once __DIR__ . '/../includes/auth.php';
require_role('patient');
$u = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    if (isset($_POST['request_appointment'])) {
        $doctor_id = (int)$_POST['doctor_id'];
        $date = $_POST['date']; $time = $_POST['time'];
        $reason = trim($_POST['reason']);
        $stmt = $pdo->prepare('INSERT INTO appointments (patient_id,doctor_id,appointment_date,appointment_time,reason,status,created_by) VALUES (?,?,?,?,?,?,?)');
        $stmt->execute([$u['id'],$doctor_id,$date,$time,$reason,'requested',$u['id']]);
        log_action('request_appointment','طلب موعد جديد','appointment',$pdo->lastInsertId());
        flash('success','تم إرسال طلب الموعد، بانتظار تأكيد الطبيب');
        header('Location: appointments.php'); exit;
    }
    if (isset($_POST['cancel'])) {
        $id = (int)$_POST['id'];
        $pdo->prepare('UPDATE appointments SET status="cancelled" WHERE id=? AND patient_id=?')->execute([$id,$u['id']]);
        log_action('cancel_appointment','إلغاء موعد','appointment',$id);
        flash('success','تم إلغاء الموعد');
        header('Location: appointments.php'); exit;
    }
}

// بحث وفلترة
$status_filter = $_GET['status'] ?? '';
$search = trim($_GET['q'] ?? '');
$page = max(1,(int)($_GET['page'] ?? 1));
$per = 10; $offset = ($page-1)*$per;

$where = ['a.patient_id = ?']; $params = [$u['id']];
if ($status_filter) { $where[] = 'a.status = ?'; $params[] = $status_filter; }
if ($search) { $where[] = '(d.full_name LIKE ? OR a.reason LIKE ?)'; $params[] = "%$search%"; $params[] = "%$search%"; }
$wsql = implode(' AND ', $where);

$total = $pdo->prepare("SELECT COUNT(*) FROM appointments a JOIN users d ON a.doctor_id=d.id WHERE $wsql");
$total->execute($params); $total = $total->fetchColumn();
$pages = ceil($total / $per);

$stmt = $pdo->prepare("SELECT a.*, d.full_name AS doctor_name FROM appointments a JOIN users d ON a.doctor_id=d.id WHERE $wsql ORDER BY a.appointment_date DESC, a.appointment_time DESC LIMIT $per OFFSET $offset");
$stmt->execute($params);
$rows = $stmt->fetchAll();

$doctors = $pdo->query("SELECT id,full_name FROM users WHERE role='doctor' AND status='approved' ORDER BY full_name")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<div class="card">
  <h2>طلب موعد جديد</h2>
  <form method="post">
    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
    <div class="form-row">
      <div class="form-group"><label>الطبيب</label>
        <select name="doctor_id" required>
          <option value="">— اختر —</option>
          <?php foreach($doctors as $d): ?>
          <option value="<?= $d['id'] ?>"><?= e($d['full_name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group"><label>التاريخ</label><input type="date" name="date" min="<?= date('Y-m-d') ?>" required></div>
      <div class="form-group"><label>الوقت</label><input type="time" name="time" required></div>
    </div>
    <div class="form-group"><label>سبب الزيارة</label><textarea name="reason" rows="2"></textarea></div>
    <button type="submit" name="request_appointment" class="btn-primary">طلب الموعد</button>
  </form>
</div>

<div class="card">
  <h2>مواعيدي</h2>
  <form class="toolbar" method="get">
    <input type="text" name="q" placeholder="بحث (الطبيب أو السبب)" value="<?= e($search) ?>">
    <select name="status">
      <option value="">كل الحالات</option>
      <?php foreach(['requested','confirmed','completed','cancelled'] as $s): ?>
      <option value="<?= $s ?>" <?= $status_filter===$s?'selected':'' ?>><?= $s ?></option>
      <?php endforeach; ?>
    </select>
    <button class="btn-primary">تصفية</button>
  </form>

  <?php if (!$rows): ?><p style="color:var(--text-muted)">لا توجد مواعيد</p>
  <?php else: ?>
  <div class="table-wrap"><table>
    <tr><th>التاريخ</th><th>الوقت</th><th>الطبيب</th><th>السبب</th><th>الحالة</th><th></th></tr>
    <?php foreach($rows as $r): ?>
    <tr>
      <td><?= e($r['appointment_date']) ?></td>
      <td><?= e($r['appointment_time']) ?></td>
      <td><?= e($r['doctor_name']) ?></td>
      <td><?= e($r['reason']) ?></td>
      <td><span class="badge badge-<?= e($r['status']) ?>"><?= e($r['status']) ?></span></td>
      <td>
        <?php if (in_array($r['status'],['requested','confirmed'])): ?>
        <form method="post" data-confirm="هل تريد إلغاء الموعد؟" style="display:inline">
          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
          <input type="hidden" name="id" value="<?= $r['id'] ?>">
          <button name="cancel" class="btn-danger">إلغاء</button>
        </form>
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
  </table></div>
  <?php if ($pages>1): ?>
  <div class="pagination">
    <?php for($i=1;$i<=$pages;$i++): ?>
      <a href="?page=<?= $i ?>&q=<?= urlencode($search) ?>&status=<?= urlencode($status_filter) ?>" class="<?= $i==$page?'active':'' ?>"><?= $i ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
