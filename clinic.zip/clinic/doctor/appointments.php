<?php
$page_title = 'إدارة المواعيد';
require_once __DIR__ . '/../includes/auth.php';
require_role(['doctor','admin']);
$u = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    if (isset($_POST['create'])) {
        $patient_id = (int)$_POST['patient_id'];
        $pdo->prepare('INSERT INTO appointments (patient_id,doctor_id,appointment_date,appointment_time,reason,status,created_by) VALUES (?,?,?,?,?,?,?)')
            ->execute([$patient_id,$u['role']==='admin'?(int)$_POST['doctor_id']:$u['id'],$_POST['date'],$_POST['time'],trim($_POST['reason']),'confirmed',$u['id']]);
        log_action('create_appointment','إنشاء موعد','appointment',$pdo->lastInsertId());
        flash('success','تم إنشاء الموعد');
        header('Location: appointments.php'); exit;
    }
    if (isset($_POST['update_status'])) {
        $id = (int)$_POST['id']; $status = $_POST['status'];
        if (!in_array($status,['requested','confirmed','completed','cancelled'])) die('حالة غير صالحة');
        $pdo->prepare('UPDATE appointments SET status=? WHERE id=?')->execute([$status,$id]);
        log_action('update_appointment_status',"تغيير حالة: $status",'appointment',$id);
        flash('success','تم التحديث');
        header('Location: appointments.php'); exit;
    }
    if (isset($_POST['delete'])) {
        $id = (int)$_POST['id'];
        $pdo->prepare('DELETE FROM appointments WHERE id=?')->execute([$id]);
        log_action('delete_appointment','حذف موعد','appointment',$id);
        flash('success','تم الحذف');
        header('Location: appointments.php'); exit;
    }
    if (isset($_POST['edit'])) {
        $id = (int)$_POST['id'];
        $pdo->prepare('UPDATE appointments SET appointment_date=?, appointment_time=?, reason=? WHERE id=?')
            ->execute([$_POST['date'],$_POST['time'],trim($_POST['reason']),$id]);
        log_action('edit_appointment','تعديل موعد','appointment',$id);
        flash('success','تم التعديل');
        header('Location: appointments.php'); exit;
    }
}

$search = trim($_GET['q'] ?? ''); $status_filter = $_GET['status'] ?? '';
$page = max(1,(int)($_GET['page'] ?? 1)); $per = 15; $offset = ($page-1)*$per;

$where = []; $params = [];
if ($u['role'] === 'doctor') { $where[] = 'a.doctor_id = ?'; $params[] = $u['id']; }
if ($status_filter) { $where[] = 'a.status = ?'; $params[] = $status_filter; }
if ($search) { $where[] = '(p.full_name LIKE ? OR a.reason LIKE ?)'; $params[] = "%$search%"; $params[] = "%$search%"; }
$wsql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$total = $pdo->prepare("SELECT COUNT(*) FROM appointments a JOIN users p ON a.patient_id=p.id $wsql");
$total->execute($params); $total = $total->fetchColumn();
$pages = ceil($total/$per);

$stmt = $pdo->prepare("SELECT a.*, p.full_name AS patient_name, d.full_name AS doctor_name FROM appointments a JOIN users p ON a.patient_id=p.id JOIN users d ON a.doctor_id=d.id $wsql ORDER BY a.appointment_date DESC, a.appointment_time DESC LIMIT $per OFFSET $offset");
$stmt->execute($params); $rows = $stmt->fetchAll();

$patients = $pdo->query("SELECT id,full_name FROM users WHERE role='patient' ORDER BY full_name")->fetchAll();
$doctors = $pdo->query("SELECT id,full_name FROM users WHERE role='doctor' AND status='approved'")->fetchAll();
require_once __DIR__ . '/../includes/header.php';
?>
<div class="card">
  <h2>إنشاء موعد جديد</h2>
  <form method="post">
    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
    <div class="form-row">
      <div class="form-group"><label>المريض</label>
        <select name="patient_id" required>
          <option value="">— اختر —</option>
          <?php foreach($patients as $p): ?><option value="<?= $p['id'] ?>"><?= e($p['full_name']) ?></option><?php endforeach; ?>
        </select>
      </div>
      <?php if ($u['role']==='admin'): ?>
      <div class="form-group"><label>الطبيب</label>
        <select name="doctor_id" required>
          <?php foreach($doctors as $d): ?><option value="<?= $d['id'] ?>"><?= e($d['full_name']) ?></option><?php endforeach; ?>
        </select>
      </div>
      <?php endif; ?>
      <div class="form-group"><label>التاريخ</label><input type="date" name="date" required></div>
      <div class="form-group"><label>الوقت</label><input type="time" name="time" required></div>
    </div>
    <div class="form-group"><label>السبب</label><input type="text" name="reason"></div>
    <button name="create" class="btn-primary">إنشاء</button>
  </form>
</div>

<div class="card">
  <h2>المواعيد</h2>
  <form class="toolbar" method="get">
    <input type="text" name="q" placeholder="بحث (مريض/سبب)" value="<?= e($search) ?>">
    <select name="status">
      <option value="">كل الحالات</option>
      <?php foreach(['requested','confirmed','completed','cancelled'] as $s): ?>
      <option value="<?= $s ?>" <?= $status_filter===$s?'selected':'' ?>><?= $s ?></option>
      <?php endforeach; ?>
    </select>
    <button class="btn-primary">تصفية</button>
  </form>
  <div class="table-wrap"><table>
    <tr><th>التاريخ</th><th>الوقت</th><th>المريض</th><?php if($u['role']==='admin'):?><th>الطبيب</th><?php endif;?><th>السبب</th><th>الحالة</th><th>إجراءات</th></tr>
    <?php foreach($rows as $r): ?>
    <tr>
      <td><?= e($r['appointment_date']) ?></td>
      <td><?= e($r['appointment_time']) ?></td>
      <td><a href="patient-file.php?id=<?= $r['patient_id'] ?>"><?= e($r['patient_name']) ?></a></td>
      <?php if($u['role']==='admin'):?><td><?= e($r['doctor_name']) ?></td><?php endif;?>
      <td><?= e($r['reason']) ?></td>
      <td>
        <form method="post" style="display:inline">
          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
          <input type="hidden" name="id" value="<?= $r['id'] ?>">
          <select name="status" onchange="this.form.submit()" style="padding:4px;border-radius:4px">
            <?php foreach(['requested','confirmed','completed','cancelled'] as $s): ?>
            <option value="<?= $s ?>" <?= $r['status']===$s?'selected':'' ?>><?= $s ?></option>
            <?php endforeach; ?>
          </select>
          <input type="hidden" name="update_status" value="1">
        </form>
      </td>
      <td class="row-actions">
        <a href="edit-appointment.php?id=<?= $r['id'] ?>" class="btn-secondary">تعديل</a>
        <form method="post" data-confirm="حذف الموعد؟" style="display:inline">
          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
          <input type="hidden" name="id" value="<?= $r['id'] ?>">
          <button name="delete" class="btn-danger">حذف</button>
        </form>
      </td>
    </tr>
    <?php endforeach; ?>
  </table></div>
  <?php if ($pages>1): ?>
  <div class="pagination">
    <?php for($i=1;$i<=$pages;$i++): ?>
      <a href="?page=<?= $i ?>&q=<?= urlencode($search) ?>&status=<?= urlencode($status_filter) ?>" class="<?= $i==$page?'active':'' ?>"><?= $i ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
