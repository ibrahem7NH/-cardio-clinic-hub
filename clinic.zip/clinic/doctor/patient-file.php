<?php
$page_title = 'ملف المريض';
require_once __DIR__ . '/../includes/auth.php';
require_role(['doctor','admin']);

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM users WHERE id=? AND role='patient'");
$stmt->execute([$id]); $p = $stmt->fetch();
if (!$p) { http_response_code(404); die('مريض غير موجود'); }

$rec = $pdo->prepare('SELECT * FROM medical_records WHERE patient_id=?');
$rec->execute([$id]); $record = $rec->fetch();
if (!$record) {
    $pdo->prepare('INSERT INTO medical_records (patient_id) VALUES (?)')->execute([$id]);
    $rec->execute([$id]); $record = $rec->fetch();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_record'])) {
    require_csrf();
    $pdo->prepare('UPDATE medical_records SET blood_type=?, blood_pressure=?, sugar_level=?, cholesterol=?, weight=?, height=?, allergies=?, chronic_diseases=?, current_medications=?, smoking_status=?, family_history=?, notes=?, updated_by=? WHERE patient_id=?')
        ->execute([$_POST['blood_type']?:null,$_POST['blood_pressure'],$_POST['sugar_level'],$_POST['cholesterol'],$_POST['weight']?:null,$_POST['height']?:null,$_POST['allergies'],$_POST['chronic_diseases'],$_POST['current_medications'],$_POST['smoking_status'],$_POST['family_history'],$_POST['notes'],current_user()['id'],$id]);
    log_action('update_medical_record','تحديث ملف طبي','user',$id);
    flash('success','تم حفظ الملف الطبي');
    header("Location: patient-file.php?id=$id"); exit;
}

$rxs = $pdo->prepare('SELECT p.*, d.full_name AS doctor_name FROM prescriptions p JOIN users d ON p.doctor_id=d.id WHERE p.patient_id=? ORDER BY p.issued_at DESC');
$rxs->execute([$id]); $rxs = $rxs->fetchAll();

$appts = $pdo->prepare('SELECT a.*, d.full_name AS doctor_name FROM appointments a JOIN users d ON a.doctor_id=d.id WHERE a.patient_id=? ORDER BY a.appointment_date DESC LIMIT 10');
$appts->execute([$id]); $appts = $appts->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<div class="card">
  <h2><?= e($p['full_name']) ?></h2>
  <div class="form-row">
    <div><strong>البريد:</strong> <?= e($p['email']) ?></div>
    <div><strong>الهاتف:</strong> <?= e($p['phone']) ?></div>
    <div><strong>الجنس:</strong> <?= e($p['gender']) ?></div>
    <div><strong>الميلاد:</strong> <?= e($p['date_of_birth']) ?></div>
  </div>
  <div style="margin-top:14px">
    <a href="write-prescription.php?patient_id=<?= $id ?>" class="btn-primary">كتابة وصفة</a>
    <a href="edit-patient.php?id=<?= $id ?>" class="btn-secondary">تعديل البيانات</a>
  </div>
</div>

<div class="card">
  <h2>الملف الطبي</h2>
  <form method="post">
    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
    <div class="form-row">
      <div class="form-group"><label>فصيلة الدم</label>
        <select name="blood_type">
          <option value="">—</option>
          <?php foreach(['A+','A-','B+','B-','AB+','AB-','O+','O-'] as $bt): ?>
          <option value="<?= $bt ?>" <?= $record['blood_type']===$bt?'selected':'' ?>><?= $bt ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group"><label>ضغط الدم</label><input type="text" name="blood_pressure" value="<?= e($record['blood_pressure']) ?>"></div>
      <div class="form-group"><label>السكر</label><input type="text" name="sugar_level" value="<?= e($record['sugar_level']) ?>"></div>
      <div class="form-group"><label>الكوليسترول</label><input type="text" name="cholesterol" value="<?= e($record['cholesterol']) ?>"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>الوزن (كغ)</label><input type="number" step="0.1" name="weight" value="<?= e($record['weight']) ?>"></div>
      <div class="form-group"><label>الطول (سم)</label><input type="number" step="0.1" name="height" value="<?= e($record['height']) ?>"></div>
      <div class="form-group"><label>التدخين</label>
        <select name="smoking_status">
          <option value="never" <?= $record['smoking_status']==='never'?'selected':'' ?>>لا</option>
          <option value="former" <?= $record['smoking_status']==='former'?'selected':'' ?>>سابقاً</option>
          <option value="current" <?= $record['smoking_status']==='current'?'selected':'' ?>>حالياً</option>
        </select>
      </div>
    </div>
    <div class="form-group"><label>الحساسية</label><textarea name="allergies" rows="2"><?= e($record['allergies']) ?></textarea></div>
    <div class="form-group"><label>الأمراض المزمنة</label><textarea name="chronic_diseases" rows="2"><?= e($record['chronic_diseases']) ?></textarea></div>
    <div class="form-group"><label>الأدوية الحالية</label><textarea name="current_medications" rows="2"><?= e($record['current_medications']) ?></textarea></div>
    <div class="form-group"><label>التاريخ العائلي</label><textarea name="family_history" rows="2"><?= e($record['family_history']) ?></textarea></div>
    <div class="form-group"><label>ملاحظات الطبيب</label><textarea name="notes" rows="3"><?= e($record['notes']) ?></textarea></div>
    <button type="submit" name="update_record" class="btn-primary">حفظ الملف الطبي</button>
  </form>
</div>

<div class="card">
  <h3>الوصفات السابقة</h3>
  <?php if (!$rxs): ?><p style="color:var(--text-muted)">لا توجد وصفات</p>
  <?php else: ?>
  <table>
    <tr><th>التاريخ</th><th>الطبيب</th><th>التشخيص</th></tr>
    <?php foreach($rxs as $rx): ?>
    <tr><td><?= e($rx['issued_at']) ?></td><td><?= e($rx['doctor_name']) ?></td><td><?= e($rx['diagnosis']) ?></td></tr>
    <?php endforeach; ?>
  </table>
  <?php endif; ?>
</div>

<div class="card">
  <h3>سجل المواعيد</h3>
  <?php if (!$appts): ?><p style="color:var(--text-muted)">لا توجد مواعيد</p>
  <?php else: ?>
  <table>
    <tr><th>التاريخ</th><th>الوقت</th><th>الطبيب</th><th>الحالة</th></tr>
    <?php foreach($appts as $a): ?>
    <tr><td><?= e($a['appointment_date']) ?></td><td><?= e($a['appointment_time']) ?></td><td><?= e($a['doctor_name']) ?></td><td><span class="badge badge-<?= e($a['status']) ?>"><?= e($a['status']) ?></span></td></tr>
    <?php endforeach; ?>
  </table>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
