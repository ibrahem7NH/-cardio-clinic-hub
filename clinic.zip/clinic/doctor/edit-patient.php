<?php
$page_title = 'تعديل مريض';
require_once __DIR__ . '/../includes/auth.php';
require_role(['doctor','admin']);

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM users WHERE id=? AND role='patient'");
$stmt->execute([$id]); $p = $stmt->fetch();
if (!$p) { http_response_code(404); die('مريض غير موجود'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $pdo->prepare('UPDATE users SET full_name=?, phone=?, date_of_birth=?, gender=?, address=? WHERE id=?')
        ->execute([trim($_POST['full_name']), trim($_POST['phone']), $_POST['dob']?:null, $_POST['gender']?:null, trim($_POST['address']), $id]);
    log_action('edit_patient','تعديل بيانات مريض','user',$id);
    flash('success','تم التحديث');
    header('Location: patients.php'); exit;
}
require_once __DIR__ . '/../includes/header.php';
?>
<div class="card">
  <h2>تعديل: <?= e($p['full_name']) ?></h2>
  <form method="post">
    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
    <div class="form-row">
      <div class="form-group"><label>الاسم الكامل</label><input type="text" name="full_name" value="<?= e($p['full_name']) ?>" required></div>
      <div class="form-group"><label>الهاتف</label><input type="tel" name="phone" value="<?= e($p['phone']) ?>"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>تاريخ الميلاد</label><input type="date" name="dob" value="<?= e($p['date_of_birth']) ?>"></div>
      <div class="form-group"><label>الجنس</label>
        <select name="gender">
          <option value="">—</option>
          <option value="male" <?= $p['gender']==='male'?'selected':'' ?>>ذكر</option>
          <option value="female" <?= $p['gender']==='female'?'selected':'' ?>>أنثى</option>
        </select>
      </div>
    </div>
    <div class="form-group"><label>العنوان</label><textarea name="address" rows="2"><?= e($p['address']) ?></textarea></div>
    <button type="submit" class="btn-primary">حفظ</button>
    <a href="patients.php" class="btn-secondary">إلغاء</a>
  </form>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
