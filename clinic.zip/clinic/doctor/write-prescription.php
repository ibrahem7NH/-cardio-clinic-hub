<?php
$page_title = 'كتابة وصفة';
require_once __DIR__ . '/../includes/auth.php';
require_role(['doctor','admin']);
$u = current_user();

$patient_id = (int)($_GET['patient_id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM users WHERE id=? AND role='patient'");
$stmt->execute([$patient_id]); $patient = $stmt->fetch();
if (!$patient) { http_response_code(404); die('مريض غير موجود'); }

if ($_SERVER['REQUEST_METHOD']==='POST') {
    require_csrf();
    $diagnosis = trim($_POST['diagnosis']);
    $notes = trim($_POST['notes']);
    $pdo->prepare('INSERT INTO prescriptions (patient_id,doctor_id,diagnosis,notes,issued_at) VALUES (?,?,?,?,CURDATE())')
        ->execute([$patient_id,$u['id'],$diagnosis,$notes]);
    $rx_id = $pdo->lastInsertId();

    $names = $_POST['med_name'] ?? [];
    foreach ($names as $i => $name) {
        if (!trim($name)) continue;
        $pdo->prepare('INSERT INTO prescription_medications (prescription_id,medication_name,dosage,frequency,duration,instructions) VALUES (?,?,?,?,?,?)')
            ->execute([$rx_id,trim($name),trim($_POST['med_dose'][$i]??''),trim($_POST['med_freq'][$i]??''),trim($_POST['med_duration'][$i]??''),trim($_POST['med_inst'][$i]??'')]);
    }
    log_action('write_prescription','كتابة وصفة','prescription',$rx_id);
    flash('success','تم حفظ الوصفة');
    header("Location: patient-file.php?id=$patient_id"); exit;
}
require_once __DIR__ . '/../includes/header.php';
?>
<div class="card">
  <h2>وصفة طبية لـ <?= e($patient['full_name']) ?></h2>
  <form method="post">
    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
    <div class="form-group"><label>التشخيص</label><textarea name="diagnosis" rows="2" required></textarea></div>

    <h3 style="margin:16px 0 10px">الأدوية</h3>
    <div id="meds">
      <?php for($i=0;$i<3;$i++): ?>
      <div class="form-row" style="margin-bottom:6px">
        <input type="text" name="med_name[]" placeholder="اسم الدواء">
        <input type="text" name="med_dose[]" placeholder="الجرعة (مثلاً 500 ملغ)">
        <input type="text" name="med_freq[]" placeholder="التكرار (مثلاً 3 مرات يومياً)">
        <input type="text" name="med_duration[]" placeholder="المدة (مثلاً 7 أيام)">
        <input type="text" name="med_inst[]" placeholder="تعليمات">
      </div>
      <?php endfor; ?>
    </div>

    <div class="form-group"><label>ملاحظات</label><textarea name="notes" rows="2"></textarea></div>
    <button class="btn-primary">حفظ الوصفة</button>
    <a href="patient-file.php?id=<?= $patient_id ?>" class="btn-secondary">إلغاء</a>
  </form>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
