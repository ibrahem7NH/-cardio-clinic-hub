<?php
$page_title = 'تعديل موعد';
require_once __DIR__ . '/../includes/auth.php';
require_role(['doctor','admin']);

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare('SELECT a.*, p.full_name AS patient_name FROM appointments a JOIN users p ON a.patient_id=p.id WHERE a.id=?');
$stmt->execute([$id]); $a = $stmt->fetch();
if (!$a) { http_response_code(404); die('غير موجود'); }

if ($_SERVER['REQUEST_METHOD']==='POST') {
    require_csrf();
    $pdo->prepare('UPDATE appointments SET appointment_date=?, appointment_time=?, reason=?, notes=? WHERE id=?')
        ->execute([$_POST['date'],$_POST['time'],trim($_POST['reason']),trim($_POST['notes']),$id]);
    log_action('edit_appointment','تعديل موعد','appointment',$id);
    flash('success','تم التحديث');
    header('Location: appointments.php'); exit;
}
require_once __DIR__ . '/../includes/header.php';
?>
<div class="card">
  <h2>تعديل موعد — <?= e($a['patient_name']) ?></h2>
  <form method="post">
    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
    <div class="form-row">
      <div class="form-group"><label>التاريخ</label><input type="date" name="date" value="<?= e($a['appointment_date']) ?>" required></div>
      <div class="form-group"><label>الوقت</label><input type="time" name="time" value="<?= e($a['appointment_time']) ?>" required></div>
    </div>
    <div class="form-group"><label>السبب</label><input type="text" name="reason" value="<?= e($a['reason']) ?>"></div>
    <div class="form-group"><label>ملاحظات</label><textarea name="notes" rows="3"><?= e($a['notes']) ?></textarea></div>
    <button class="btn-primary">حفظ</button>
    <a href="appointments.php" class="btn-secondary">إلغاء</a>
  </form>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
