<?php
$page_title = 'المرضى';
require_once __DIR__ . '/../includes/auth.php';
require_role(['doctor','admin']);
$u = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    if (isset($_POST['add_patient'])) {
        $username = trim($_POST['username']); $email = trim($_POST['email']);
        $full_name = trim($_POST['full_name']); $phone = trim($_POST['phone']);
        $dob = $_POST['dob'] ?: null; $gender = $_POST['gender'] ?: null;
        $password = $_POST['password'];
        if (strlen($password) < 8) { flash('error','كلمة المرور قصيرة'); header('Location: patients.php'); exit; }
        try {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $pdo->prepare('INSERT INTO users (username,email,password,full_name,phone,role,status,date_of_birth,gender) VALUES (?,?,?,?,?,"patient","active",?,?)')
                ->execute([$username,$email,$hash,$full_name,$phone,$dob,$gender]);
            $new_id = $pdo->lastInsertId();
            $pdo->prepare('INSERT INTO medical_records (patient_id) VALUES (?)')->execute([$new_id]);
            log_action('add_patient',"إضافة مريض: $full_name",'user',$new_id);
            flash('success','تمت إضافة المريض');
        } catch (PDOException $e) { flash('error','اسم المستخدم أو البريد مستخدم'); }
        header('Location: patients.php'); exit;
    }
    if (isset($_POST['delete'])) {
        $id = (int)$_POST['id'];
        $pdo->prepare('DELETE FROM users WHERE id=? AND role="patient"')->execute([$id]);
        log_action('delete_patient','حذف مريض','user',$id);
        flash('success','تم حذف المريض');
        header('Location: patients.php'); exit;
    }
}

$search = trim($_GET['q'] ?? '');
$page = max(1,(int)($_GET['page'] ?? 1)); $per = 15; $offset = ($page-1)*$per;
$where = "role='patient'"; $params = [];
if ($search) { $where .= ' AND (full_name LIKE ? OR username LIKE ? OR email LIKE ? OR phone LIKE ?)';
  $params = ["%$search%","%$search%","%$search%","%$search%"]; }

$total = $pdo->prepare("SELECT COUNT(*) FROM users WHERE $where");
$total->execute($params); $total = $total->fetchColumn();
$pages = ceil($total/$per);

$stmt = $pdo->prepare("SELECT * FROM users WHERE $where ORDER BY created_at DESC LIMIT $per OFFSET $offset");
$stmt->execute($params); $rows = $stmt->fetchAll();
require_once __DIR__ . '/../includes/header.php';
?>
<div class="card">
  <h2>إضافة مريض جديد</h2>
  <form method="post">
    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
    <div class="form-row">
      <div class="form-group"><label>الاسم الكامل</label><input type="text" name="full_name" required></div>
      <div class="form-group"><label>اسم المستخدم</label><input type="text" name="username" required></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>البريد</label><input type="email" name="email" required></div>
      <div class="form-group"><label>الهاتف</label><input type="tel" name="phone"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>تاريخ الميلاد</label><input type="date" name="dob"></div>
      <div class="form-group"><label>الجنس</label>
        <select name="gender"><option value="">—</option><option value="male">ذكر</option><option value="female">أنثى</option></select>
      </div>
      <div class="form-group"><label>كلمة المرور</label><input type="password" name="password" required minlength="8"></div>
    </div>
    <button type="submit" name="add_patient" class="btn-primary">إضافة</button>
  </form>
</div>

<div class="card">
  <h2>قائمة المرضى</h2>
  <form class="toolbar" method="get">
    <input type="text" name="q" placeholder="بحث (الاسم/البريد/الهاتف)" value="<?= e($search) ?>">
    <button class="btn-primary">بحث</button>
  </form>
  <div class="table-wrap"><table>
    <tr><th>الاسم</th><th>البريد</th><th>الهاتف</th><th>تاريخ التسجيل</th><th>إجراءات</th></tr>
    <?php foreach($rows as $r): ?>
    <tr>
      <td><?= e($r['full_name']) ?></td>
      <td><?= e($r['email']) ?></td>
      <td><?= e($r['phone']) ?></td>
      <td><?= e(substr($r['created_at'],0,10)) ?></td>
      <td class="row-actions">
        <a href="patient-file.php?id=<?= $r['id'] ?>" class="btn-secondary">الملف</a>
        <a href="/clinic/chat.php?patient_id=<?= $r['id'] ?>" class="btn-secondary">💬 محادثة</a>
        <a href="edit-patient.php?id=<?= $r['id'] ?>" class="btn-secondary">تعديل</a>
        <form method="post" data-confirm="حذف المريض نهائياً؟" style="display:inline">
          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
          <input type="hidden" name="id" value="<?= $r['id'] ?>">
          <button name="delete" class="btn-danger">حذف</button>
        </form>
      </td>
    </tr>
    <?php endforeach; ?>
  </table></div>
  <?php if ($pages>1): ?>
  <div class="pagination">
    <?php for($i=1;$i<=$pages;$i++): ?>
      <a href="?page=<?= $i ?>&q=<?= urlencode($search) ?>" class="<?= $i==$page?'active':'' ?>"><?= $i ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
