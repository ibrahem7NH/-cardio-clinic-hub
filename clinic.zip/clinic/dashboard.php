<?php
require_once __DIR__ . '/includes/auth.php';
require_login();
$u = current_user();

if ($u['role'] === 'admin') { header('Location: admin/dashboard.php'); exit; }

$page_title = 'لوحتي';
require_once __DIR__ . '/includes/header.php';
?>
<div class="card">
  <h2>أهلاً، <?= e($u['full_name']) ?></h2>
  <p style="color:var(--text-muted)">الدور: <?= $u['role']==='doctor'?'طبيب':'مريض' ?></p>
</div>

<?php if ($u['role'] === 'patient'): 
  $appts = $pdo->prepare('SELECT a.*, d.full_name AS doctor_name FROM appointments a JOIN users d ON a.doctor_id=d.id WHERE a.patient_id=? AND a.appointment_date >= CURDATE() ORDER BY a.appointment_date, a.appointment_time LIMIT 5');
  $appts->execute([$u['id']]); $appts = $appts->fetchAll();
  $rx = $pdo->prepare('SELECT COUNT(*) FROM prescriptions WHERE patient_id=?'); $rx->execute([$u['id']]); $rx_count = $rx->fetchColumn();
?>
<div class="stats-grid">
  <div class="stat-card"><div class="stat-value"><?= count($appts) ?></div><div class="stat-label">مواعيد قادمة</div></div>
  <div class="stat-card"><div class="stat-value"><?= $rx_count ?></div><div class="stat-label">وصفات طبية</div></div>
</div>
<div class="card">
  <h3>مواعيدي القادمة</h3>
  <?php if (!$appts): ?><p style="color:var(--text-muted)">لا توجد مواعيد قادمة</p>
  <?php else: ?>
  <div class="table-wrap"><table>
    <tr><th>التاريخ</th><th>الوقت</th><th>الطبيب</th><th>الحالة</th></tr>
    <?php foreach($appts as $a): ?>
    <tr>
      <td><?= e($a['appointment_date']) ?></td>
      <td><?= e($a['appointment_time']) ?></td>
      <td><?= e($a['doctor_name']) ?></td>
      <td><span class="badge badge-<?= e($a['status']) ?>"><?= e($a['status']) ?></span></td>
    </tr>
    <?php endforeach; ?>
  </table></div>
  <?php endif; ?>
  <a href="patient/appointments.php" class="btn-secondary" style="margin-top:14px">عرض كل المواعيد</a>
</div>

<?php elseif ($u['role'] === 'doctor'):
  $patients_count = $pdo->query('SELECT COUNT(*) FROM users WHERE role="patient"')->fetchColumn();
  $today = $pdo->prepare('SELECT COUNT(*) FROM appointments WHERE doctor_id=? AND appointment_date=CURDATE()');
  $today->execute([$u['id']]);
  $pending = $pdo->prepare('SELECT COUNT(*) FROM appointments WHERE doctor_id=? AND status="requested"');
  $pending->execute([$u['id']]);
?>
<div class="stats-grid">
  <div class="stat-card"><div class="stat-value"><?= $today->fetchColumn() ?></div><div class="stat-label">مواعيد اليوم</div></div>
  <div class="stat-card"><div class="stat-value"><?= $pending->fetchColumn() ?></div><div class="stat-label">طلبات بانتظار التأكيد</div></div>
  <div class="stat-card"><div class="stat-value"><?= $patients_count ?></div><div class="stat-label">إجمالي المرضى</div></div>
</div>
<div class="card">
  <h3>وصول سريع</h3>
  <a href="doctor/appointments.php" class="btn-primary">إدارة المواعيد</a>
  <a href="doctor/patients.php" class="btn-secondary">قائمة المرضى</a>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
