-- ============================================
-- نظام إدارة عيادة جراحة القلب
-- قاعدة البيانات الكاملة
-- ============================================

CREATE DATABASE IF NOT EXISTS heart_clinic CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE heart_clinic;

-- جدول التخصصات
CREATE TABLE specialties (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- جدول المستخدمين (يشمل المرضى والأطباء والأدمن)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    role ENUM('patient','doctor','admin') NOT NULL,
    status ENUM('pending','approved','rejected','active') DEFAULT 'active',
    specialty_id INT NULL,
    license_number VARCHAR(50) NULL,
    date_of_birth DATE NULL,
    gender ENUM('male','female') NULL,
    address TEXT NULL,
    avatar VARCHAR(255) DEFAULT NULL,
    last_login DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (specialty_id) REFERENCES specialties(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- الملف الطبي
CREATE TABLE medical_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    blood_type ENUM('A+','A-','B+','B-','AB+','AB-','O+','O-') NULL,
    allergies TEXT,
    chronic_diseases TEXT,
    current_medications TEXT,
    blood_pressure VARCHAR(20),
    sugar_level VARCHAR(20),
    cholesterol VARCHAR(20),
    weight DECIMAL(5,2),
    height DECIMAL(5,2),
    smoking_status ENUM('never','former','current') DEFAULT 'never',
    family_history TEXT,
    notes TEXT,
    updated_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- المواعيد
CREATE TABLE appointments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL,
    reason VARCHAR(255),
    notes TEXT,
    status ENUM('requested','confirmed','completed','cancelled') DEFAULT 'requested',
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- الوصفات الطبية
CREATE TABLE prescriptions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    appointment_id INT NULL,
    diagnosis TEXT,
    notes TEXT,
    issued_at DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (appointment_id) REFERENCES appointments(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- تفاصيل أدوية الوصفة (لمتابعة الأدوية)
CREATE TABLE prescription_medications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    prescription_id INT NOT NULL,
    medication_name VARCHAR(150) NOT NULL,
    dosage VARCHAR(100),
    frequency VARCHAR(100),
    duration VARCHAR(100),
    instructions TEXT,
    FOREIGN KEY (prescription_id) REFERENCES prescriptions(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- سجل العمليات (Audit Log)
CREATE TABLE audit_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    action VARCHAR(100) NOT NULL,
    target_type VARCHAR(50),
    target_id INT NULL,
    description TEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



 
-- ============================================
-- بيانات ابتدائية (Seed Data)
-- ============================================

-- تخصصات
INSERT INTO specialties (name, description) VALUES
('جراحة القلب', 'عمليات القلب المفتوح والقسطرة'),
('أمراض القلب', 'تشخيص وعلاج أمراض القلب'),
('جراحة الأوعية الدموية', 'علاج تصلب الشرايين والدوالي'),
('قلب الأطفال', 'أمراض القلب الخلقية عند الأطفال');

-- حساب الأدمن الافتراضي
-- اسم المستخدم: admin | كلمة المرور: Admin@123
INSERT INTO users (username, email, password, full_name, phone, role, status) VALUES
('admin', 'admin@clinic.local',
 '$2b$10$cFhzUuSLUs43/47Fof2amOm8F5c8jItRnvpVVhAVLx7fv.WIbdNO.',
 'مدير النظام', '0000000000', 'admin', 'active');

-- ملاحظة: غيّر كلمة المرور فور تسجيل الدخول الأول
