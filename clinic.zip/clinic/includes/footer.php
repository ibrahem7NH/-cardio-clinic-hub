</main>
<footer class="footer">
  <div class="container">
    <p>© <?= date('Y') ?> عيادة جراحة القلب — جميع الحقوق محفوظة</p>
  </div>
</footer>
<script src="/clinic/assets/app.js"></script>
</body>
</html>
