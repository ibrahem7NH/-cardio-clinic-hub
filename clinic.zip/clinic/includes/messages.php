<?php
require_once __DIR__ . '/auth.php';

function get_or_create_conversation($patient_id, $doctor_id) {
    global $pdo;
    $stmt = $pdo->prepare('SELECT * FROM conversations WHERE patient_id=? AND doctor_id=?');
    $stmt->execute([$patient_id, $doctor_id]);
    $c = $stmt->fetch();
    if ($c) return $c;
    $pdo->prepare('INSERT INTO conversations (patient_id, doctor_id) VALUES (?,?)')
        ->execute([$patient_id, $doctor_id]);
    $id = $pdo->lastInsertId();
    return $pdo->query("SELECT * FROM conversations WHERE id=$id")->fetch();
}

function user_in_conversation($conv, $user) {
    if (!$conv || !$user) return false;
    if ($user['role'] === 'admin') return true;
    return ($user['role']==='patient' && $conv['patient_id']==$user['id'])
        || ($user['role']==='doctor'  && $conv['doctor_id']==$user['id']);
}

function unread_messages_count($user) {
    global $pdo;
    if (!$user) return 0;
    $field = $user['role']==='patient' ? 'patient_id' : 'doctor_id';
    if (!in_array($user['role'], ['patient','doctor'])) return 0;
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM messages m
        JOIN conversations c ON c.id=m.conversation_id
        WHERE c.$field=? AND m.sender_id<>? AND m.is_read=0");
    $stmt->execute([$user['id'], $user['id']]);
    return (int)$stmt->fetchColumn();
}
