<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/messages.php';
$user = current_user();
$theme = $_COOKIE['theme'] ?? 'light';
$unread_msgs = $user ? unread_messages_count($user) : 0;
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl" data-theme="<?= e($theme) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($page_title) ? e($page_title) . ' | ' : '' ?>عيادة جراحة القلب</title>
<link rel="stylesheet" href="/clinic/assets/style.css">
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
</head>
<body>
<header class="topbar">
  <div class="container topbar-inner">
    <a href="/clinic/index.php" class="brand">
      <span class="brand-icon">❤</span>
      <span>عيادة جراحة القلب</span>
    </a>
    <nav class="main-nav">
      <?php if ($user): ?>
        <a href="/clinic/dashboard.php">لوحتي</a>
        <?php if ($user['role'] === 'patient'): ?>
          <a href="/clinic/patient/appointments.php">مواعيدي</a>
          <a href="/clinic/patient/medical-record.php">ملفي الطبي</a>
          <a href="/clinic/patient/prescriptions.php">وصفاتي</a>
        <?php elseif ($user['role'] === 'doctor'): ?>
          <a href="/clinic/doctor/patients.php">المرضى</a>
          <a href="/clinic/doctor/appointments.php">المواعيد</a>
        <?php elseif ($user['role'] === 'admin'): ?>
          <a href="/clinic/admin/dashboard.php">الإحصائيات</a>
          <a href="/clinic/admin/approve-doctors.php">موافقات الأطباء</a>
          <a href="/clinic/admin/users.php">المستخدمون</a>
          <a href="/clinic/admin/specialties.php">التخصصات</a>
          <a href="/clinic/admin/audit-log.php">سجل العمليات</a>
        <?php endif; ?>
        <?php if (in_array($user['role'], ['patient','doctor','admin'])): ?>
          <a href="/clinic/messages.php">💬 المحادثات<?php if($unread_msgs):?> <span style="background:#e11;color:#fff;border-radius:999px;padding:.05rem .45rem;font-size:.75rem"><?= $unread_msgs ?></span><?php endif;?></a>
        <?php endif; ?>
        <a href="/clinic/profile.php">الملف الشخصي</a>
        <a href="/clinic/logout.php" class="btn-link">خروج</a>
      <?php else: ?>
        <a href="/clinic/login.php">تسجيل دخول</a>
        <a href="/clinic/register.php" class="btn-primary">إنشاء حساب</a>
      <?php endif; ?>
      <button id="themeToggle" class="theme-btn" aria-label="تبديل الوضع">🌓</button>
    </nav>
  </div>
</header>
<main class="container main-content">
<?php if ($m = flash('success')): ?><div class="alert alert-success"><?= e($m) ?></div><?php endif; ?>
<?php if ($m = flash('error')): ?><div class="alert alert-error"><?= e($m) ?></div><?php endif; ?>
