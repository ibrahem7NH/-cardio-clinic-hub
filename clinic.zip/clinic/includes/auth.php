<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/db.php';

// CSRF Token
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token ?? '');
}

function require_csrf() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!verify_csrf($_POST['csrf_token'] ?? '')) {
            die('خطأ أمني: رمز CSRF غير صالح');
        }
    }
}

// تنظيف المخرجات
function e($value) {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

// التحقق من تسجيل الدخول
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function current_user() {
    global $pdo;
    if (!is_logged_in()) return null;
    static $user = null;
    if ($user === null) {
        $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
    }
    return $user;
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: /clinic/login.php');
        exit;
    }
    // التحقق من حالة الحساب
    $u = current_user();
    if (!$u || ($u['status'] !== 'active' && $u['status'] !== 'approved')) {
        session_destroy();
        header('Location: /clinic/login.php?error=account_inactive');
        exit;
    }
}

function require_role($roles) {
    require_login();
    $u = current_user();
    $roles = (array)$roles;
    if (!in_array($u['role'], $roles)) {
        http_response_code(403);
        die('غير مصرّح لك بالوصول إلى هذه الصفحة');
    }
}

// Session timeout (30 دقيقة)
function check_session_timeout() {
    $timeout = 1800;
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
        session_unset();
        session_destroy();
        header('Location: /clinic/login.php?error=timeout');
        exit;
    }
    $_SESSION['last_activity'] = time();
}

// سجل العمليات
function log_action($action, $description = '', $target_type = null, $target_id = null) {
    global $pdo;
    $stmt = $pdo->prepare('INSERT INTO audit_log (user_id, action, target_type, target_id, description, ip_address) VALUES (?, ?, ?, ?, ?, ?)');
    $stmt->execute([
        $_SESSION['user_id'] ?? null,
        $action,
        $target_type,
        $target_id,
        $description,
        $_SERVER['REMOTE_ADDR'] ?? null
    ]);
}

// رسائل الفلاش
function flash($key, $msg = null) {
    if ($msg === null) {
        $m = $_SESSION['flash'][$key] ?? null;
        unset($_SESSION['flash'][$key]);
        return $m;
    }
    $_SESSION['flash'][$key] = $msg;
}

check_session_timeout();
