<?php
$page_title = 'تسجيل الدخول';
require_once __DIR__ . '/includes/auth.php';
if (is_logged_in()) { header('Location: dashboard.php'); exit; }

$error = '';
if (isset($_GET['error'])) {
    if ($_GET['error'] === 'timeout') $error = 'انتهت جلستك، الرجاء تسجيل الدخول مجدداً';
    if ($_GET['error'] === 'account_inactive') $error = 'حسابك غير مفعّل أو بانتظار الموافقة';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ? OR email = ?');
    $stmt->execute([$username, $username]);
    $u = $stmt->fetch();

    if ($u && password_verify($password, $u['password'])) {
        if ($u['role'] === 'doctor' && $u['status'] === 'pending') {
            $error = 'حسابك بانتظار موافقة الأدمن';
        } elseif ($u['status'] === 'rejected') {
            $error = 'تم رفض حسابك';
        } else {
            session_regenerate_id(true);
            $_SESSION['user_id'] = $u['id'];
            $_SESSION['last_activity'] = time();
            $pdo->prepare('UPDATE users SET last_login = NOW() WHERE id = ?')->execute([$u['id']]);
            log_action('login', "تسجيل دخول: {$u['username']}");
            header('Location: dashboard.php'); exit;
        }
    } else {
        $error = 'بيانات الدخول غير صحيحة';
    }
}
require_once __DIR__ . '/includes/header.php';
?>
<div class="auth-page">
  <div class="card auth-card">
    <h1>تسجيل الدخول</h1>
    <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
    <form method="post">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
      <div class="form-group"><label>اسم المستخدم أو البريد</label><input type="text" name="username" required autofocus></div>
      <div class="form-group"><label>كلمة المرور</label><input type="password" name="password" required></div>
      <button type="submit" class="btn-primary" style="width:100%">دخول</button>
    </form>
    <p style="text-align:center;margin-top:14px;font-size:14px">
      ليس لديك حساب؟ <a href="register.php" style="color:var(--primary)">أنشئ حساباً</a>
    </p>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
