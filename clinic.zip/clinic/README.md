# نظام إدارة عيادة جراحة القلب

نظام كامل بـ PHP + MySQL لإدارة عيادة جراحة قلب بثلاث طبقات صلاحيات (مريض / طبيب / أدمن).

## المتطلبات

- PHP 7.4 أو أحدث (مع إضافة PDO_MySQL)
- MySQL 5.7 أو MariaDB 10
- خادم Apache أو Nginx

## التثبيت

### 1) إنشاء قاعدة البيانات
افتح phpMyAdmin أو سطر الأوامر ونفّذ:
```sql
SOURCE /path/to/database.sql;
```
أو من phpMyAdmin: استورد ملف `database.sql`.

### 2) إعداد الاتصال
عدّل `config/db.php` ببياناتك:
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'heart_clinic');
define('DB_USER', 'root');
define('DB_PASS', '');
```

### 3) النشر
- **محلياً (XAMPP):** انسخ المجلد إلى `htdocs/clinic/`
- **استضافة:** ارفع الملفات عبر FTP إلى مجلد فرعي اسمه `clinic`

### 4) فتح الموقع
- محلي: `http://localhost/clinic/`
- استضافة: `https://yourdomain.com/clinic/`

> **مهم:** كل المسارات داخل الكود تفترض المجلد `/clinic/`. إذا غيّرت اسم المجلد، عدّل المسارات في `includes/header.php` و `includes/auth.php`.

## حساب الأدمن الافتراضي

```
اسم المستخدم: admin
كلمة المرور:   Admin@123
```
**غيّر كلمة المرور فوراً من صفحة الملف الشخصي بعد أول دخول.**

## الأدوار والصلاحيات

| الميزة | مريض | طبيب | أدمن |
|--------|------|------|------|
| تسجيل ذاتي | ✅ | ✅ (يحتاج موافقة) | ❌ |
| رؤية مواعيده | ✅ | — | — |
| طلب موعد | ✅ | — | — |
| إلغاء موعده | ✅ | — | — |
| رؤية ملفه الطبي | ✅ | — | — |
| رؤية وصفاته | ✅ | — | — |
| إدارة كل المواعيد | — | ✅ | ✅ |
| إدارة المرضى (CRUD) | — | ✅ | ✅ |
| تحديث الملف الطبي | — | ✅ | ✅ |
| كتابة وصفات | — | ✅ | ✅ |
| الموافقة على الأطباء | — | — | ✅ |
| إدارة المستخدمين | — | — | ✅ |
| إدارة التخصصات | — | — | ✅ |
| سجل العمليات | — | — | ✅ |

## الميزات الأمنية

- ✅ تشفير كلمات المرور بـ `password_hash()` (bcrypt)
- ✅ حماية SQL Injection بـ PDO Prepared Statements
- ✅ حماية CSRF بـ tokens في كل النماذج
- ✅ Session timeout بعد 30 دقيقة خمول
- ✅ session_regenerate_id بعد تسجيل الدخول
- ✅ تنظيف المخرجات بـ htmlspecialchars
- ✅ التحقق من الصلاحيات في كل صفحة
- ✅ سجل عمليات (Audit Log) لكل إجراء حساس

## ميزات UX

- 🌐 واجهة عربية RTL كاملة
- 🌓 وضع داكن (يحفظ في كوكي)
- 🔍 بحث وفلترة في كل الجداول
- 📄 ترقيم صفحات (Pagination)
- 🖨️ طباعة الوصفات الطبية
- 📱 تصميم متجاوب للجوال

## هيكل الملفات

```
clinic/
├── database.sql              # سكربت إنشاء قاعدة البيانات
├── README.md
├── config/
│   └── db.php                # إعدادات الاتصال
├── includes/
│   ├── auth.php              # المصادقة والصلاحيات
│   ├── header.php
│   └── footer.php
├── assets/
│   ├── style.css
│   └── app.js
├── uploads/                  # رفع الملفات (مستقبلاً)
├── index.php                 # الرئيسية
├── register.php              # إنشاء حساب
├── login.php                 # دخول
├── logout.php
├── dashboard.php             # لوحة المريض/الطبيب
├── profile.php               # الملف الشخصي
├── 404.php
├── patient/
│   ├── appointments.php      # مواعيد المريض
│   ├── medical-record.php    # ملفه الطبي
│   ├── prescriptions.php     # وصفاته
│   └── medications.php       # متابعة الأدوية
├── doctor/
│   ├── patients.php          # CRUD المرضى
│   ├── edit-patient.php
│   ├── patient-file.php      # الملف الكامل
│   ├── appointments.php      # CRUD المواعيد
│   ├── edit-appointment.php
│   └── write-prescription.php
└── admin/
    ├── dashboard.php         # الإحصائيات
    ├── approve-doctors.php   # الموافقات
    ├── users.php             # كل المستخدمين
    ├── specialties.php       # التخصصات
    └── audit-log.php         # سجل العمليات
```

## ترخيص

مفتوح للاستخدام الشخصي والتعليمي.
