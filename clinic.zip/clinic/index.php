<?php
$page_title = 'الرئيسية';
require_once __DIR__ . '/includes/header.php';
?>
<section class="hero">
  <h1>عيادة جراحة القلب</h1>
  <p>نظام متكامل لإدارة المواعيد والملفات الطبية والوصفات</p>
  <?php if (!$user): ?>
    <a href="register.php" class="btn-primary">ابدأ الآن</a>
  <?php else: ?>
    <a href="dashboard.php" class="btn-primary">الذهاب إلى لوحتي</a>
  <?php endif; ?>
</section>

<section class="features">
  <div class="feature">
    <div class="icon">📅</div>
    <h3>حجز المواعيد</h3>
    <p>احجز موعدك مع نخبة من أطباء القلب بسهولة وسرعة</p>
  </div>
  <div class="feature">
    <div class="icon">📋</div>
    <h3>الملف الطبي الإلكتروني</h3>
    <p>سجل صحي متكامل يحفظ تاريخك الطبي بأمان</p>
  </div>
  <div class="feature">
    <div class="icon">💊</div>
    <h3>الوصفات الطبية</h3>
    <p>استلم وصفاتك إلكترونياً وتابع جرعات أدويتك</p>
  </div>
  <div class="feature">
    <div class="icon">🔒</div>
    <h3>أمان وخصوصية</h3>
    <p>بياناتك مشفّرة ومحفوظة وفق أعلى معايير الأمان</p>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
