<?php
$page_title = '404';
require_once __DIR__ . '/includes/header.php';
?>
<div class="auth-page">
  <div class="card auth-card" style="text-align:center">
    <h1 style="font-size:72px;color:var(--primary)">404</h1>
    <p style="margin-bottom:20px">الصفحة المطلوبة غير موجودة</p>
    <a href="/clinic/index.php" class="btn-primary">العودة للرئيسية</a>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
